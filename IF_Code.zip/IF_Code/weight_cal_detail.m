function [sMap,Cmax,i_mean2] = weight_cal_detail(I,p,r)
R=2*r+1;

[h,w,~,~]=size(I);
N1 = boxfilter(ones(h, w), r);

if size(I,4)==1
N = size(I,3);
else
    N = size(I,4);
end
    
C = zeros(size(I,1),size(I,2),N);
i_mean2=zeros(size(I,1),size(I,2),N);
for i = 1:N
    
    if size(I,4)==1
    img = I(:,:,i);
        i_mean2(:,:,i)=boxfilter(img, r)./ N1;
     i_var2= boxfilter(img.*img, r) ./ N1- i_mean2(:,:,i).* i_mean2(:,:,i);
      
    i_var2=sqrt(max(i_var2,0));
    
    C(:,:,i) = i_var2 * sqrt( R^2  )+ 1e-12; % signal strengh
    else
       img = I(:,:,:,i);
       
       
       i_mean2(:,:,i)=boxfilter(img(:,:,1), r)./ N1+boxfilter(img(:,:,2), r)./ N1+boxfilter(img(:,:,3), r)./ N1;
        i_mean2(:,:,i)= i_mean2(:,:,i)./3;
   i_var2= boxfilter(img(:,:,1).*img(:,:,1), r)./ N1+ boxfilter(img(:,:,2).*img(:,:,2), r)./ N1+...
         boxfilter(img(:,:,3).*img(:,:,3), r)./ N1- i_mean2(:,:,i).* i_mean2(:,:,i)*3;
     
    i_var2 = i_var2./3;       
    i_var2=sqrt(max(i_var2,0));

    C(:,:,i) = i_var2 * sqrt( 3*R^2  )+ 1e-12; % signal strengh
    end
    
end

Cmax=max(C,[],3);

sMap1 = C.^p; % signal structure weighting map
sMap2 = C.^(p-1);
sMap = sMap1 + 1e-12;
normalizer = sum(sMap,3);
sMap = sMap2 ./ repmat(normalizer,[1, 1, N]) ;