function [Im,Iout] = Enhancement(I,r)
%%
Lamda = 10;
Cli = 5/255.0;

[h,w,~,~] = size(I);

N1 = boxfilter(ones(h, w), r);
Iout = I;
if size(I,4)==1
    N = size(I,3);
else
    N = size(I,4);
end
i_mean2=ones(size(I,1),size(I,2),N);


I_k=ones(size(I,1),size(I,2),N);

for i = 1:N
    if size(I,4)==1
        img = I(:,:,i);
        img(img<=Cli) = Cli;
        i_mean2(:,:,i) = boxfilter(img, r)./ N1 + eps;
        
        tt = i_mean2(:,:,i);
        tmp = i_mean2(:,:,i);
        tmp(tmp > 0.5) = 0.5;
        tmp = 1./(log(Lamda*0.5./tmp)/log(Lamda))*max(tt(:));%% Paper
    
        I_k(:,:,i) = tmp;
        Iout(:,:,i) = img./tmp;
    else
        img = I(:,:,:,i);
        img(img<=Cli) = Cli;
        i_mean2(:,:,i)=boxfilter(img(:,:,1), r)./ N1 + boxfilter(img(:,:,2), r)./ N1 + boxfilter(img(:,:,3), r)./ N1;
        i_mean2(:,:,i)= i_mean2(:,:,i)./3 + eps;
        
        
        tt = i_mean2(:,:,i);
        tmp = i_mean2(:,:,i);
        tmp(tmp > 0.5) = 0.5;
        tmp = 1./(log(Lamda*0.5./tmp)/log(Lamda))*max(tt(:)); %% Paper
   
        I_k(:,:,i) = tmp;
        
        Iout(:,:,:,i) = img./repmat(tmp,[1 1 3]);
    end
    
end
tmp = mean(i_mean2,3);
tt = max(tmp(:));
Im = ones(h,w)*tt;
end

