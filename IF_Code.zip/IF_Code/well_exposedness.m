function C = well_exposedness(I)
N = size(I,3);
C = zeros(size(I,1),size(I,2),N);
for i = 1:N
    X=I(:,:,i);
    tmp1=2/pi*atan(20*(X.*(X<=0.5)));
    tmp2=2/pi*atan(20*((1-X).*(X>0.5)));
    C(:,:,i)=tmp1 + tmp2;
end
end
