function C = fangcha(I)
countWindowt = ones(11, 11);
countWindow=countWindowt./sum(countWindowt(:));
N = size(I,3);
C = zeros(size(I,1),size(I,2),N);
for i = 1:N
    img=I(:,:,i);
    i_mean2=filter2(countWindow,img,'same');
    i_var2=filter2(countWindow,img.*img,'same')-i_mean2.*i_mean2;
    C(:,:,i)=sqrt(max(i_var2,0));
end
end

