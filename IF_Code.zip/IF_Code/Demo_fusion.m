
% ========================================================================
% Multi-Exposure Image Fusion via Perception Enhanced Structural Patch Decomposition, IF,2023
% Copyright(c) 2023, Junchao Zhang, Yidong Luo, Junbin Huang, Ying Liu and Jiayi Ma 
% All Rights Reserved.
% ----------------------------------------------------------------------
% Permission to use, copy, or modify this software and its documentation
% for educational and research purposes only and without fee is hereby
% granted, provided that this copyright notice and the original authors'
% names appear on all copies and supporting documentation. This program
% shall not be used, rewritten, or adapted as the basis of a commercial
% software or hardware product without first obtaining permission of the
% authors. The authors make no representations about the suitability of
% this software for any purpose. It is provided "as is" without express
% or implied warranty.
%----------------------------------------------------------------------
% Please refer to the following paper:
% Junchao Zhang, Yidong Luo, Junbin Huang, Ying Liu and Jiayi Ma. 
% Multi-Exposure Image Fusion via Perception Enhanced Structural Patch Decomposition. 
% Information Fusion, 2023, 99: 101895.

% Our code is built based on the following paper:
% H. Li et al., "Fast Multi-Scale Structural Patch Decomposition for Multi-Exposure Image Fusion, 2020, TIP"
%----------------------------------------------------------------------
clear;
close all;


images_path = './s51/';
imgSeqColor = loadImg(images_path); 
r1=4;
I_f = fusion(imgSeqColor,r1);
figure,imshow(I_f,[])
