function [fI3, i_meant,aa,N1,Im] = scale_interm(imgSeqColor,r)

[h,w,n]=size(imgSeqColor);
N = boxfilter(ones(h, w), r);


tem=ones(h, w);
tem(:,2:2:w)=0;
tem(2:2:h,:)=0;
N1= boxfilter(tem, r);

p=4;

[Im,imgSeqColor] = Enhancement(imgSeqColor,r);
[WD, Cmax,i_mean2]= weight_cal_detail(imgSeqColor,p,r);
WD=WD.*repmat(Cmax,[1 1 n]);
WD=WD.*repmat(Im,[1 1 n]);
F_temp2_detail=zeros(h,w,n);
%% 
i_meant=zeros(ceil(h/2),ceil(w/2),2);
for i = 1:n
    
    
    aa=i_mean2(:,:,i).*tem;
    i_meant(:,:,i)=aa(1:2:h,1:2:w);
    W_D1=boxfilter(i_mean2(:,:,i).*WD(:,:,i), r)./ N;
    W_D2=boxfilter(WD(:,:,i), r)./ N;
    F_temp2_detail(:,:,i)=W_D2.*(imgSeqColor(:,:,i))-W_D1;
    
end

fI3=sum(F_temp2_detail,3);

end



