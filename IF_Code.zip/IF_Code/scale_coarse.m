function [fI3, i_meant,aa,N1,Im] = scale_coarse(imgSeqColor,r)

[h,w,n]=size(imgSeqColor);
N = boxfilter(ones(h, w), r);

tem=ones(h, w);
tem(:,2:2:w)=0;
tem(2:2:h,:)=0;
N1= boxfilter(tem, r);

p=4;
[Im,imgSeqColor] = Enhancement(imgSeqColor,r);
[WD, Cmax,i_mean2]= weight_cal_detail(imgSeqColor,p,r);

WD=WD.*repmat(Cmax,[1 1 n]);
WD=WD.*repmat(Im,[1 1 n]);

fangcha_para = 1.0;
wellexp_para = 1.0;
W = ones(size(imgSeqColor));
W = W.*fangcha(imgSeqColor).^fangcha_para;
W = W.*well_exposedness(imgSeqColor).^wellexp_para;
W = W + 1e-12; %avoids division by zero
WB = W./repmat(sum(W,3),[1 1 n]);


F_temp2_detail=zeros(h,w,n);
F_temp2_base=zeros(h,w,n);
F_temp2=zeros(h,w,n);


%%
i_meant=zeros(ceil(h/2),ceil(w/2),2);
for i = 1:n
    
    
    aa=i_mean2(:,:,i).*tem;
    i_meant(:,:,i)=aa(1:2:h,1:2:w);
    W_D1=boxfilter(i_mean2(:,:,i).*WD(:,:,i), r)./ N;
    W_D2=boxfilter(WD(:,:,i), r)./ N;
    W_B2=boxfilter(i_mean2(:,:,i).*WB(:,:,i).*Im, r)./ N;
    
    
    F_temp2_detail(:,:,i)=W_D2.*(imgSeqColor(:,:,i))-W_D1;
    F_temp2_base(:,:,i)= W_B2;
    F_temp2(:,:,i)=F_temp2_detail(:,:,i)+F_temp2_base(:,:,i);
    
end

fI3=sum(F_temp2,3);
end




